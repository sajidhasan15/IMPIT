<p>
    hi, <br>
    You have a new contact email from your website. <br><br>
    <strong>Name: {{ $data['name'] }}</strong> <br>
    <strong>Name: {{ $data['name'] }}</strong> <br>
    <strong>Email: {{ $data['email'] }}</strong> <br>
    <strong>Message: {{ $data['message'] }}</strong> <br>
</p>